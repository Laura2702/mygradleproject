package com.tom;

public class MyApplication {
    public static void main(String[] args) {
        System.out.println("Meine erste Gradle Application!");
    }
}
